"""Independent assertions and ideal AC nodal solution of KiCad's exported netlist."""
from pathlib import Path
import sys,json,math,re,cmath
import numpy as np
from sexpr import parse,child,children
P=Path(__file__).resolve().parents[1]
data=parse((P/'design/checks/SubController.net').read_text())
comps={str(child(c,'ref')[1]):dict(value=str(child(c,'value')[1]),foot=str(child(c,'footprint')[1])) for c in children(child(data,'components'),'comp')}
pins={};nets={}
for n in children(child(data,'nets'),'net'):
 name=str(child(n,'name')[1]);nets[name]=[]
 for node in children(n,'node'):
  ref,pin=str(child(node,'ref')[1]),str(child(node,'pin')[1]);pins.setdefault(ref,{})[pin]=name;nets[name].append((ref,pin))
checks=[]
def check(ok,description):
 checks.append(description);assert ok,description
def equal(ref,expect):
 for pin,net in expect.items():check(pins[ref][pin]==net,f'{ref}.{pin} = {net}')
for i in range(1,7):equal('U'+str(i),{'8':'+15V','4':'-15V'})
equal('U7',{'12':'+5A','4':'+5A','13':'-5A','15':'GND','10':'GND','5':'GND','9':'GND','16':'ATT_IN','14':'ATT_OUT','8':'CS_RUN'})
equal('K1',{'2':'REF_L','7':'REF_R','4':'LFE','5':'LFE','3':'SEL_L','6':'SEL_R','1':'+5R','8':'AV_COIL'})
equal('K2',{'2':'REF_L_RETURN','7':'REF_R_RETURN','4':'LFE_RETURN','5':'LFE_RETURN','3':'GND','6':'GND','1':'+5R','8':'AV_COIL'})
equal('K3',{'2':'REF_LP','4':'MONO','3':'LEVEL_IN','7':'HP_OUT','5':'AV_HP_SELECT','6':'HP_SELECTED','8':'AV_COIL'})
equal('K4',{'2':'GND','4':'AMP_SERIES','3':'AMP_OUT','8':'MUTE_COIL'})
for net in ['REF_L','REF_R','REF_L_RETURN','REF_R_RETURN','LFE','LFE_RETURN']:
 check(all(r.startswith(('J','K')) for r,p in nets[net]),net+' has no permanent board-ground bias/protection path')
for net in ['TRIG_PLUS','TRIG_MINUS','TRIG_LED_A']:
 check(all(r in ['J20','U10','R63','D1'] for r,p in nets[net]),net+' only opto-side components')
equal('D1',{'1':'TRIG_LED_A','2':'TRIG_MINUS'})
equal('D2',{'1':'+15V','2':'+5A'});equal('D3',{'1':'-5A','2':'-15V'});equal('D4',{'1':'+15V','2':'+5R'})
for ref,drain in [('D5','AV_COIL'),('D6','MUTE_COIL')]:equal(ref,{'1':'+5R','2':drain})
equal('U8',{'6':'UPDI','1':'+5R','8':'GND'})
equal('U9',{'19':'RAIL_GOOD','18':'RUN_REQUEST','17':'AV_ENABLE','20':'+5R','3':'GND','4':'GND','5':'GND','9':'GND'})
for ref in ['U11','U13']:equal(ref,{'1':'+15V','2':'GND'})
equal('U12',{'1':'GND','2':'-15V','3':'-5A'})
equal('U14',{'1':'VREF_2V5','2':'GND'})
for ref in ['Q1','Q2','Q3','Q4','Q5','Q6','Q7','Q8','Q9']:equal(ref,{'3':'GND'})
for ref in ['C44','C45','C47','C49','C51','C56']:
 pp=pins[ref];check((pp['1']=='GND' and pp['2'].startswith('-')) or (pp['2']=='GND' and pp['1'].startswith('+')),ref+' electrolytic polarity')
# Footprint pad sets versus all manufacturer-numbered symbol pins (NC pads included).
base=Path('/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints')
for ref,c in comps.items():
 lib,fp=c['foot'].split(':');file=(P/'libraries/SubController.pretty' if lib=='SubController' else base/(lib+'.pretty'))/(fp+'.kicad_mod')
 f=parse(file.read_text());pads={str(p[1]) for p in children(f,'pad') if str(p[1])};check(set(pins[ref])==pads,ref+' footprint pad set matches symbol pins')
# Function from values, never copied resistance/capacitance into AC topology.
def value(v):
 v=v.split()[0].upper().replace('FILM','');m=re.fullmatch(r'(\d+(?:\.\d+)?)([RKNMUP]?)(\d*)',v);assert m,v
 a,scale,b=m.groups();return float(a+('.'+b if b else ''))*{'':1,'R':1,'K':1e3,'N':1e-9,'M':1e6,'U':1e-6,'P':1e-12}[scale]
ops=[(pins[f'U{i}'][a],pins[f'U{i}'][b],pins[f'U{i}'][o]) for i in range(1,7) for a,b,o in [('3','2','1'),('5','6','7')]]
# Each scenario connects actual relay / jumper pins and solves ideal opamps + CS analog VCVS.
def solve(freq,mode='REF',bank=3,slope=24,hp=1,ap=None,pol=0,mute=False,level=1,source='both',noise=False):
 parent={n:n for n in nets}
 def root(n):
  while parent[n]!=n:n=parent[n]
  return n
 def join(a,b):parent[root(a)]=root(b)
 def short(ref,a,b):join(pins[ref][str(a)],pins[ref][str(b)])
 for k in ['K1','K2','K3']:
  short(k,3,2 if mode=='REF' else 4);short(k,6,7 if mode=='REF' else 5)
 short('K4',3,2 if mute else 4)
 for j in range(5,9):short(f'J{j}',2*bank+1,2*bank+2)
 for j in [11,12]:short(f'J{j}',2*hp+1,2*hp+2)
 short('J4',2,1 if slope==12 else 3);short('J10',2,1 if ap is None else 3)
 short('J13',2,1);short('J14',2,3);short('J15',2,1 if pol==0 else 3)
 gnd=root('GND');branches=[];noisy_R=[]
 for ref,c in comps.items():
  if ref[0] not in ['R','C']:continue
  a,b=(root(pins[ref][p]) for p in ['1','2'])
  # Only analog section R1..R55 C1..C40, all local supply decouplers skip.
  if ref[0]=='R' and int(ref[1:])>55:continue
  if ref[0]=='C' and int(ref[1:])>40:continue
  if any(n.startswith(('+','-')) for n in [a,b]):continue
  v=value(c['value']);y=1/v if ref[0]=='R' else 2j*math.pi*freq*v;branches.append((a,b,y))
  if ref[0]=='R':noisy_R.append((a,b,v))
 if ap is not None:branches.append((root('PHASE_TOP'),root('PHASE_WIPER'),1/max(ap,1e-6)))
 branches.append((root('ATT_IN'),gnd,1/10000));branches.append((root('AMP_OUT'),gnd,1/22000))
 activeops=[tuple(root(x) for x in o) for o in ops];vcs=[(root('ATT_OUT'),root('ATT_IN'),level)]
 selected=['REF_L','REF_R'] if mode=='REF' else ['LFE'];voltages=[(root(x),1 if source=='both' or x.endswith('_L') else 0) for x in selected]
 # Keep only actual branch/opamp/source connected nodes; dangling frequency resistor tails valid.
 names=set(n for a,b,y in branches for n in [a,b])|set(n for o in activeops for n in o)|set(n for o in vcs for n in o[:2])|set(n for n,v in voltages);names.discard(gnd)
 ix={n:i for i,n in enumerate(sorted(names))};nv=len(ix);extra=len(activeops)+len(vcs)+len(voltages);A=np.zeros((nv+extra,nv+extra),complex);z=np.zeros(nv+extra,complex)
 def add(a,b,v):
  if a!=gnd and b!=gnd:A[ix[a],ix[b]]+=v
 for a,b,y in branches:add(a,a,y);add(b,b,y);add(a,b,-y);add(b,a,-y)
 k=nv
 for plus,minus,out in activeops:
  if out!=gnd:A[ix[out],k]+=1
  if plus!=gnd:A[k,ix[plus]]+=1
  if minus!=gnd:A[k,ix[minus]]-=1
  k+=1
 for out,inp,gain in vcs:
  A[ix[out],k]+=1;A[k,ix[out]]+=1;A[k,ix[inp]]-=gain;k+=1
 for n,v in voltages:
  A[ix[n],k]+=1;A[k,ix[n]]+=1;z[k]=v;k+=1
 result=np.linalg.solve(A,z)
 if noise:
  e=np.zeros(nv+extra,complex);e[ix[root('AMP_OUT')]]=1;adj=np.linalg.solve(A.T,e)
  sensitivity=lambda n:0 if n==gnd else adj[ix[n]]
  psd_R=sum(abs(sensitivity(a)-sensitivity(b))**2*4*1.380649e-23*300/r for a,b,r in noisy_R)
  psd_ops=sum(abs(adj[nv+i])**2*(4.5e-9)**2+(abs(sensitivity(a))**2+abs(sensitivity(b))**2)*(0.7e-12)**2 for i,(a,b,o) in enumerate(activeops))
  psd_CS=abs(adj[nv+len(activeops)])**2*(4.2e-6)**2/(20000-20)
  return [psd_R,psd_ops,psd_CS]
 return 0 if root('AMP_OUT')==gnd else result[ix[root('AMP_OUT')]]
from analyse import L,H,AP
load=1/(1+100*(1/22000+1/100000));input_gain=47000/48000
maxerr=0;cases=0
for mode in ['REF','AV']:
 for bank in range(7):
  for slope in [12,24]:
   for hp in range(3):
    for ap in [None,25000]:
     for pol in [0,180]:
      for freq in [5,20,50,100,500]:
       r=[28000,22600,18700,16200,14000,11300,9310][bank];aa,bb=[(16900,34000),(12700,25500),(10200,20500)][hp]
       expected=input_gain/(1+2j*math.pi*freq*100e-12/(1/1000+1/47000))*load*(1 if mode=='AV' else L(freq,r,r)**(slope//12)*H(freq,aa,bb))*(1 if ap is None else AP(freq,2200+ap*value(comps['R43']['value'])/(ap+value(comps['R43']['value']))))*(-1 if pol else 1)
       actual=solve(freq,mode,bank,slope,hp,ap,pol);err=abs(actual-expected);maxerr=max(maxerr,err);cases+=1
       assert err<1e-7,(mode,bank,slope,hp,ap,pol,freq,actual,expected,err)
check(abs(solve(70,source='left')/solve(70)-.5)<1e-8,'One REF channel produces half correlated-stereo output')
check(solve(70,mute=True)==0,'Output relay OFF grounds amplifier input')
check(abs(solve(70,level=.1)/solve(70)-.1)<1e-8,'Analog attenuation setting scales output')
report={'assertions_passed':len(checks),'assertions':checks,'ideal_AC_scenarios_passed':cases,'maximum_complex_response_error':maxerr,'limitations':'Ideal opamps and CS gain model; excludes finite GBW, device nonlinearities/noise/offsets and real relay transients. No SPICE or bench qualification.'}
(P/'design/checks/connectivity-and-AC.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'{len(checks)} connectivity/package assertions, {cases} AC scenarios passed; max complex error {maxerr:.3g}')

noise_results={}
for mode,ap in [('REF',None),('REF',50000),('AV',None),('AV',50000)]:
 fs=np.geomspace(20,20000,151);psds=np.array([solve(f,mode=mode,ap=ap,noise=True) for f in fs]);powers=np.trapezoid(psds,fs,axis=0)
 noise_results[f'{mode}_phase_'+('bypass' if ap is None else 'full')]={'resistor_uVrms':float(np.sqrt(powers[0])*1e6),'opamp_uVrms':float(np.sqrt(powers[1])*1e6),'CS_typ_uVrms':float(np.sqrt(powers[2])*1e6),'total_typ_uVrms':float(np.sqrt(sum(powers))*1e6),'total_with_CS_max_other_typ_uVrms':float(np.sqrt(powers[0]+powers[1]+4*powers[2])*1e6)}
(P/'design/checks/noise-estimates.json').write_text(json.dumps({'conditions':'20Hz-20kHz, 300K, ideal zero-impedance source, opamp white en=4.5nV and in=0.7pA, CS specified integrated noise treated as equivalent white PSD; excludes 1/f, source excess noise, hum, clock feedthrough and nonlinearities. Estimates, not guaranteed limits.', 'results':noise_results},indent=2)+'\n')
print(json.dumps(noise_results,indent=2))
