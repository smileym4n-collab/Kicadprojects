from pathlib import Path
import math, cmath, json, csv, random
P=Path(__file__).resolve().parents[1]
freqs=[40,50,60,70,80,100,120]
rs=[28000,22600,18700,16200,14000,11300,9310]
lp=[dict(label=f,R=r,f0=1/(2*math.pi*r*math.sqrt(2)*100e-9),Q=1/math.sqrt(2)) for f,r in zip(freqs,rs)]
hp=[dict(label=f,R1=a,R2=b,f0=1/(2*math.pi*440e-9*math.sqrt(a*b)),Q=math.sqrt(a*b)/(2*a)) for f,a,b in [(15,16900,34000),(20,12700,25500),(25,10200,20500)]]
def L(f,r1,r2,cf=200e-9,cg=100e-9):
 s=2j*math.pi*f
 return 1/(1+s*cg*(r1+r2)+s*s*r1*r2*cf*cg)
def H(f,a,b,c1=440e-9,c2=440e-9):
 s=2j*math.pi*f
 return s*s*c1*c2*a*b/(1+s*a*(c1+c2)+s*s*c1*c2*a*b)
def AP(f,r): return (1-2j*math.pi*f*r*220e-9)/(1+2j*math.pi*f*r*220e-9)
rows=[]
for i in range(1201):
 f=10**(math.log10(2)+i/1200*math.log10(1000/2))
 l=L(f,16200,16200);h=H(f,12700,25500)
 rows.append([f,20*math.log10(abs(l)),20*math.log10(abs(l*l)),20*math.log10(abs(h)),20*math.log10(abs(l*h)),20*math.log10(abs(l*l*h)),math.degrees(cmath.phase(l)),math.degrees(cmath.phase(h))])
with (P/'design/filter-response.csv').open('w') as fh:
 w=csv.writer(fh);w.writerow(['Hz','LP12_dB','LP24_dB','HP20_dB','REF12_HP20_dB','REF24_HP20_dB','LP12_phase_deg','HP20_phase_deg']);w.writerows(rows)
random.seed(68)
mc=[]
for _ in range(20000):
 r1=16200*random.uniform(.99,1.01);r2=16200*random.uniform(.99,1.01)
 cf=100e-9*(random.uniform(.95,1.05)+random.uniform(.95,1.05));cg=100e-9*random.uniform(.95,1.05)
 mc.append((1/(2*math.pi*math.sqrt(r1*r2*cf*cg)), math.sqrt(r1*r2*cf*cg)/(cg*(r1+r2))))
def pct(a,p): return sorted(a)[int((len(a)-1)*p)]
result={'LP':lp,'HP':hp,'tolerance_70Hz_uniform_independent_1pct_R_5pct_C':{'f0_p05_p95':[pct([a for a,b in mc],.05),pct([a for a,b in mc],.95)],'Q_p05_p95':[pct([b for a,b in mc],.05),pct([b for a,b in mc],.95)]},'phase_at_70_deg':[math.degrees(cmath.phase(AP(70,r))) for r in [2200,2200+50000*47000/(50000+47000)]],'HP20_at_40_dB':20*math.log10(abs(H(40,12700,25500))),'HP20_at_80_dB':20*math.log10(abs(H(80,12700,25500))),'HP20_phase_40_deg':math.degrees(cmath.phase(H(40,12700,25500))),'max_source_rms_nominal_CS':3.75*2/math.sqrt(2),'design_source_rms':4,'CS_input_peak_at_design':4*math.sqrt(2)/2,'typical_output_noise_floor_CS_x2_uVrms':8.4}
(P/'design/calculations.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__': print(json.dumps(result,indent=2))
