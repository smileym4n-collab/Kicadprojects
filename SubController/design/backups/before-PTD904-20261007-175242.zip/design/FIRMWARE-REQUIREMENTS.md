# Controller firmware contract — not yet implemented or bench-qualified

Audio never enters the MCU. ATtiny412 only interprets contact states and emits control signals. Keep PA0/physical pin 6 for UPDI. Use its internal oscillator; enable brownout detection at approximately 4.2 V and a watchdog. MCP23008 address is 0x20. I2C is software-driven on PA6=SDA and PA7=SCL, nominally 100 kHz; keep the bus short.

MCP23008 GP0/1 = REF encoder, GP2/3 = LFE encoder, GP4 = active-low trigger, GP5 = AV_ENABLE, GP6 = RUN_REQUEST, GP7 = RAIL_GOOD. All pins except GP5/6 remain inputs; IODIR=0x9F. Write OLAT=0 BEFORE changing IODIR. GP7 must read high before any unmute. Hardware clamps RUN regardless of firmware. Poll rail status and trigger at least every millisecond; use a state machine, not long blocking delays. Debounce encoder transitions with a complete quadrature-state decoder; reject illegal transitions.

CS3310 serial uses PA1=DATA_INV, PA2=CLK_INV, PA3=CS_INV. Three transistor collectors invert these levels. Physical clock idle LOW; data stable on rising clock edge. Transmit right byte=0 then left byte, MSB first, with physical CS LOW for the complete 16-bit transfer. Use 10 kHz clock. Physical CS HIGH is PA3 LOW. Physical DATA/CLOCK LOW are PA1/2 HIGH. Check the waveform on an oscilloscope before connecting the amplifier.

Left code: 0=mute, 1..191=attenuation, 192=unity. Reject 193..255 absolutely: the positive-gain range is not permitted. Levels use 0.5 dB steps. Default absent/corrupt EEPROM settings: REF=-30 dB (code132), AV=-12 dB (code168). Require a version, magic value and CRC before accepting stored settings; invalid records must never be interpreted as unity. Save only after two seconds of encoder inactivity, using alternating records to reduce wear. Valid deliberately calibrated levels may be restored gradually from deep attenuation; never jump directly from reset to unity.

Startup / watchdog restart:
1. Initialise serial idle states. Immediately force MCP OLAT=0 and IODIR=0x9F. A watchdog reset alone does not reset the expander; clear it explicitly before all other work.
2. Keep RUN_REQUEST=0, giving K4 OFF and CS hardware mute. Write both CS gain bytes zero.
3. Require RAIL_GOOD high continuously for 500 ms; any low restarts this timer.
4. Read selected mode, set AV_ENABLE as required, keep attenuation muted, and wait at least 50 ms for relay operation/release and analogue DC settling. Diode flyback makes release slower than the relay's bare-coil specification.
5. CS hardware MUTE must have stayed LOW for at least 2 ms to calibrate. Set RUN_REQUEST=1 only while rail status remains good. Wait 30 ms for K4 to connect; CS gain is still zero.
6. Ramp the selected, validated level upward at no more than 1 dB per 20 ms. No positive gain is allowed.

Mode change:
1. Ramp attenuation downward to deep attenuation, write code0, and wait 25 ms to cover the low-frequency zero-cross timeout.
2. Set RUN_REQUEST=0; wait 50 ms for K4 release.
3. Change AV_ENABLE, wait 50 ms, verify RAIL_GOOD, then perform steps5/6 above for that mode's independent stored level.
4. Do not operate the frequency jumpers with audio running. Panel frequency/slope/polarity switches must be changed while muted until switching transients have been measured.

Fault / power fail: hardware immediately clamps RUN_HW. Firmware sets RUN_REQUEST=0 as soon as GP7 goes low, writes CS gain0 if supplies remain valid, and requires a fresh 500 ms stable interval before rearming. The PSU's optional open-collector early-warning output connects J22. It must assert before analogue rails collapse. Arbitrarily fast supply collapse cannot be guaranteed silent by a relay with flyback diodes. No firmware can replace early-warning timing or the separate amplifier's speaker protection.

AUTO/REF/AV override is hardware via J24: AUTO connects pins1-2, REF leaves the common open (pull-up), AV connects2-3. An ON-OFF-ON panel switch makes these three states. The optocoupler-side return remains isolated in every state. RUN LED lights while K4's coil is energised; it is a commanded run indication, not proof that its contacts closed.

Bench acceptance: verify rails, reset/no-firmware mute, trigger polarity, encoder direction, serial bit order, retained settings/CRC failure, watchdog restart, each rail fault and mode-switch transients with the P68 input terminated and a scope. Only then connect the woofer and calibrate with REW.
