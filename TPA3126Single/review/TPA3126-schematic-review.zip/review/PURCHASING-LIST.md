# Purchasing list - one board

No orders placed. Recheck supplier availability before ordering. Parts already present on the existing PCB, or in an unlogged kit, must be checked physically; they are not counted as owned here.

| References | Manufacturer part number | Quantity | Reason |
|---|---|---:|---|
| U2 | PCM5122PWR | 1 | MCP explicitly reports zero. Existing circuit does not establish ownership. |
| C37, C38, C39, C40 | ECW-FE2W684J | 4 | Panasonic 680n, 450 V DC, 5% polypropylene; 17.5x7x12.5 mm, pitch 15 mm, leads 0.8 mm. DigiKey 10-ECW-FE2W684J-ND. No matching MCP inventory record. |
| C54 | UES1H470MPM | 1 | External 47u / 50 V bipolar, 10x20 mm, 5 mm pitch. No matching MCP record. |
| C1, C2, C6, C5 | MKS2C041001F00JSSD | 4 | Stock is Kemet generic 1u / 63 V, body noted 7x5 mm. Check 5 mm pitch; WIMA MPN is a verified purchase fallback, not a claim about stock identity. |
| R35, R36, R37, R38 | RC0805FR-0718RL | 0 initially; 4 optional | DNP 18R snubber tuning resistors, 125 mW; pulse rating must be checked if populated. |
| F2 | 39613150000 | 1 | Time-delay TE5, 3.15 A / 125 V. Existing 395 footprint shares TE5 mechanical case. |
| R23, R27 | RC0603FR-07100KL | 2 | 100k / 1%, 1608; owned 2012 resistors do not match retained footprint. |
| R24 | RC0603FR-0716K2L | 1 | 16k2 / 1%, 1608; no matching MCP record. |
| C53, C48, C46 | MC0603B104K500CT | 3 | 100n / 50 V X7R, 1608 metric; exact inventory record has zero. |
| U4 | TLV1117LV33DCYR | 1 | No matching inventory record. Do not substitute TS1117B. |
| D2 | SMBJ16A | 1 | Littelfuse, unidirectional SMB. No matching MCP record. |
| C45 | GRM32ER71H106KA12L | 1 | 10u / 50 V X7R, 3225 metric, retain inherited footprint. Owned 3216 parts are not substituted. |

| R12, R14 | RMCF0805FT1K20 | 2 | 1k2 / 1%, 125mW, 2012 metric; 15W revision input pad. No matching MCP record. |
| R13, R15 | RMCF0805FT1K50 | 2 | 1k5 / 1%, 125mW, 2012 metric; owned 1k5 is 1608 and does not match retained footprint. |

C56/C57 were already present in the user-saved schematic at revision start: value 1n, 1608 metric footprint, but inherited MPN C1206C104K5RACTU / ID157 describes a different value/package. Their actual selection/stock remains unresolved; no substitution was made during this power revision.
